// Removed unused import
import { mysqlTable, serial, text, int, varchar, datetime, timestamp } from 'drizzle-orm/mysql-core';

export const user = mysqlTable('user', {
	id: varchar('id', { length: 255 }).primaryKey(),
	age: int('age'),
	username: varchar('username', { length: 32 }).notNull().unique(),
	passwordHash: varchar('password_hash', { length: 255 }).notNull()
});

export const session = mysqlTable('session', {
	id: varchar('id', { length: 255 }).primaryKey(),
	userId: varchar('user_id', { length: 255 })
		.notNull()
		.references(() => user.id),
	expiresAt: datetime('expires_at').notNull()
});

// Definisikan tabel items
export const items = mysqlTable('items', {
	id: int('id').primaryKey().autoincrement(),
	name: varchar('name', { length: 255 }).notNull(),
	description: text('description'),
	createdAt: timestamp('created_at')
});

export type Session = typeof session.$inferSelect;

export type User = typeof user.$inferSelect;

  
// Tipe untuk item berdasarkan schema
export type Item = typeof items.$inferSelect;
export type NewItem = typeof items.$inferInsert;