import { json, type RequestHandler } from '@sveltejs/kit';
import { db } from '$lib/server/db';
import { items } from '$lib/server/db/schema';
import type { Item, NewItem } from '$lib/server/db/schema';
import { eq } from 'drizzle-orm';

export const GET: RequestHandler = async () => {
  try {
    // Menggunakan Drizzle untuk query
    const allItems = await db.select().from(items);
    return json(allItems);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return json({ error: errorMessage }, { status: 500 });
  }
};

export const POST: RequestHandler = async ({ request }) => {
  try {
    const data = await request.json() as NewItem;
    
    // Validasi data
    if (!data.name) {
      return json({ error: 'Name is required' }, { status: 400 });
    }
    
    // Menggunakan Drizzle untuk insert
    const result = await db.insert(items).values(data);
    
    // Ambil item yang baru saja dimasukkan
    const insertedId = Number(result[0].insertId);
    const insertedItem = await db.select().from(items).where(eq(items.id, insertedId));
    
    return json(insertedItem[0], { status: 201 });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return json({ error: errorMessage }, { status: 500 });
  }
};