<script lang="ts">
  import { onMount } from 'svelte';
  import type { Item } from '$lib/server/db/schema';
  
  let items: Item[] = [];
  let newItem = { name: '', description: '' };
  let loading: boolean = true;
  let error: string | null = null;
  
  // Ambil data saat komponen dimuat
  onMount(async () => {
    try {
      const response = await fetch('/api/items');
      if (!response.ok) throw new Error('Gagal mengambil data');
      items = await response.json();
    } catch (e) {
      error = e instanceof Error ? e.message : 'Unknown error';
    } finally {
      loading = false;
    }
  });
  
  // Fungsi untuk menambah item baru
  async function addItem(): Promise<void> {
    try {
      const response = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Gagal menambahkan item');
      }
      
      const addedItem: Item = await response.json();
      items = [...items, addedItem];
      newItem = { name: '', description: '' };
    } catch (e) {
      error = e instanceof Error ? e.message : 'Unknown error';
    }
  }
</script>

<main class="container mx-auto p-4">
  <h1 class="text-3xl font-bold mb-6">Aplikasi SvelteKit dengan Drizzle ORM</h1>
  
  {#if error}
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
      {error}
    </div>
  {/if}
  
  <div class="mb-8 bg-white p-6 rounded-lg shadow-md">
    <h2 class="text-xl font-semibold mb-4">Tambah Item Baru</h2>
    <form on:submit|preventDefault={addItem} class="space-y-4">
      <div>
        <label for="name" class="block mb-1">Nama:</label>
        <input 
          id="name"
          type="text" 
          bind:value={newItem.name} 
          required
          class="w-full px-3 py-2 border rounded"
        />
      </div>
      <div>
        <label for="description" class="block mb-1">Deskripsi:</label>
        <textarea 
          id="description"
          bind:value={newItem.description} 
          class="w-full px-3 py-2 border rounded"
          rows="3"
        ></textarea>
      </div>
      <button 
        type="submit" 
        class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded"
      >
        Simpan
      </button>
    </form>
  </div>
  
  <div class="bg-white p-6 rounded-lg shadow-md">
    <h2 class="text-xl font-semibold mb-4">Daftar Item</h2>
    
    {#if loading}
      <p>Memuat data...</p>
    {:else if items.length === 0}
      <p>Belum ada data.</p>
    {:else}
      <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {#each items as item}
          <div class="border rounded p-4 hover:shadow-md transition">
            <h3 class="font-bold">{item.name}</h3>
            <p>{item.description}</p>
          </div>
        {/each}
      </div>
    {/if}
  </div>
</main>

<style>
  /* Styling tambahan jika diperlukan */
  main {
    max-width: 1200px;
  }
</style>